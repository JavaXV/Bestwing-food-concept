const jwt =
    require('jsonwebtoken');


/*
|--------------------------------------------------------------------------
| LOAD ENVIRONMENT VARIABLES
|--------------------------------------------------------------------------
|
| Loads values from the .env file.
|
*/

require('dotenv').config();


/*
|--------------------------------------------------------------------------
| AUTHENTICATE USER
|--------------------------------------------------------------------------
|
| This middleware protects routes that require login.
|
| Registration and payment routes do NOT use this middleware.
|
| Login creates the JWT.
|
| Dashboard and other protected routes use this middleware.
|
*/

function authenticate(
    req,
    res,
    next
) {


    /*
    |--------------------------------------------------------------------------
    | GET AUTHORIZATION HEADER
    |--------------------------------------------------------------------------
    */

    const header =
        req.headers.authorization;


    /*
    |--------------------------------------------------------------------------
    | CHECK AUTHORIZATION HEADER
    |--------------------------------------------------------------------------
    |
    | The expected format is:
    |
    | Authorization: Bearer YOUR_JWT_TOKEN
    |
    */

    if (
        !header ||
        !header.startsWith('Bearer ')
    ) {

        return res
            .status(401)
            .json({

                success:
                    false,

                message:
                    'Authorization token is required'

            });

    }


    try {


        /*
        |--------------------------------------------------------------------------
        | EXTRACT TOKEN
        |--------------------------------------------------------------------------
        |
        | Removes "Bearer " from the beginning of the header.
        |
        */

        const token =
            header.slice(7);


        /*
        |--------------------------------------------------------------------------
        | VERIFY JWT TOKEN
        |--------------------------------------------------------------------------
        |
        | JWT_SECRET must be stored in your .env file.
        |
        | Example:
        |
        | JWT_SECRET=your_secret_key
        |
        */

        req.auth =
            jwt.verify(
                token,
                process.env.JWT_SECRET
            );


        /*
        |--------------------------------------------------------------------------
        | CONTINUE TO REQUESTED ROUTE
        |--------------------------------------------------------------------------
        */

        next();


    } catch {


        /*
        |--------------------------------------------------------------------------
        | INVALID OR EXPIRED TOKEN
        |--------------------------------------------------------------------------
        */

        return res
            .status(401)
            .json({

                success:
                    false,

                message:
                    'Invalid or expired token'

            });

    }

}


/*
|--------------------------------------------------------------------------
| REQUIRE ADMIN
|--------------------------------------------------------------------------
|
| This middleware ensures that the authenticated user is an administrator.
|
| It should be used AFTER authenticate().
|
| Example:
|
| router.get(
|     '/manual-payments',
|     authenticate,
|     requireAdmin,
|     ...
| );
|
*/

function requireAdmin(
    req,
    res,
    next
) {


    /*
    |--------------------------------------------------------------------------
    | CHECK ADMIN STATUS
    |--------------------------------------------------------------------------
    |
    | The JWT created during admin login contains:
    |
    | isAdmin: true
    |
    */

    if (
        !req.auth?.isAdmin
    ) {

        return res
            .status(403)
            .json({

                success:
                    false,

                message:
                    'Admin access required'

            });

    }


    /*
    |--------------------------------------------------------------------------
    | ADMIN AUTHENTICATION SUCCESSFUL
    |--------------------------------------------------------------------------
    */

    next();

}


/*
|--------------------------------------------------------------------------
| EXPORT MIDDLEWARE FUNCTIONS
|--------------------------------------------------------------------------
*/

module.exports = {

    authenticate,

    requireAdmin

};