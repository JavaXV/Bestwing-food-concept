require('dotenv').config();
const express=require('express');
const path=require('path');
const bcrypt=require('bcryptjs');
const pool=require('./config/db');
const auth=require('./routes/auth');
const payment=require('./routes/payment');
const user=require('./routes/user');
const admin=require('./routes/admin');
const app=express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,'public')));
app.use('/api/auth',auth);
app.use('/api/payment',payment);
app.use('/api/user',user);
app.use('/api/admin',admin);
app.get('/health',(req,res)=>res.json({success:true,message:'API is running'}));
app.get('/',(req,res)=>res.sendFile(path.join(__dirname,'public','register.html')));

async function seedAdmin(){
 if(!process.env.ADMIN_PHONE||!process.env.ADMIN_PASSWORD) return;
 const [rows]=await pool.query('SELECT id FROM admin_users WHERE phone_number=?',[process.env.ADMIN_PHONE]);
 if(!rows.length){
  const hash=await bcrypt.hash(process.env.ADMIN_PASSWORD,12);
  await pool.query('INSERT INTO admin_users(phone_number,password_hash) VALUES(?,?)',[process.env.ADMIN_PHONE,hash]);
  console.log('Default admin created:',process.env.ADMIN_PHONE);
 }
}
const port=process.env.PORT||3000;
app.listen(port,async()=>{try{await seedAdmin();}catch(e){console.error('Admin seed error:',e.message)} console.log(`Server running on http://localhost:${port}`)});
