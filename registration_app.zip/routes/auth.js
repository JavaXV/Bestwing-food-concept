const express = require('express');

const bcrypt = require('bcryptjs');

const jwt = require('jsonwebtoken');

const pool = require('../config/db');

require('dotenv').config();

const router = express.Router();


/*
|--------------------------------------------------------------------------
| PUBLIC USER
|--------------------------------------------------------------------------
| This function removes sensitive information such as the password hash
| before sending user information to the frontend.
|--------------------------------------------------------------------------
*/

function publicUser(u, account) {

    return {

        id: u.id,

        full_name: u.full_name,

        email: u.email,

        phone_number: u.phone_number,

        gender: u.gender,

        referral: u.referral,

        payment_status: u.payment_status,

        account_status: u.account_status,

        account_number: account?.accountno || null,

        account_name: account?.account_name || null,

        created_at: u.created_at

    };

}


/*
|--------------------------------------------------------------------------
| USER REGISTRATION
|--------------------------------------------------------------------------
| POST /api/auth/register
|
| IMPORTANT:
| No JWT token is required for registration.
| No Authorization header is required.
|--------------------------------------------------------------------------
*/

router.post('/register', async (req, res) => {

    try {

        /*
        |--------------------------------------------------------------------------
        | GET REGISTRATION DATA
        |--------------------------------------------------------------------------
        */

        const {
            full_name,
            email,
            phone_number,
            gender,
            referral,
            password
        } = req.body;


        /*
        |--------------------------------------------------------------------------
        | VALIDATE REQUIRED FIELDS
        |--------------------------------------------------------------------------
        */

        if (
            !full_name ||
            !email ||
            !phone_number ||
            !gender ||
            !password
        ) {

            return res.status(400).json({

                success: false,

                message:
                    'Full name, email, phone number, gender and password are required'

            });

        }


        /*
        |--------------------------------------------------------------------------
        | CHECK PASSWORD LENGTH
        |--------------------------------------------------------------------------
        */

        if (password.length < 6) {

            return res.status(400).json({

                success: false,

                message: 'Password must be at least 6 characters'

            });

        }


        /*
        |--------------------------------------------------------------------------
        | CHECK IF EMAIL OR PHONE NUMBER ALREADY EXISTS
        |--------------------------------------------------------------------------
        */

        const [dup] = await pool.query(

            `
            SELECT id
            FROM users
            WHERE email = ?
            OR phone_number = ?
            LIMIT 1
            `,

            [
                email,
                phone_number
            ]

        );


        /*
        |--------------------------------------------------------------------------
        | DUPLICATE USER
        |--------------------------------------------------------------------------
        */

        if (dup.length) {

            return res.status(409).json({

                success: false,

                message:
                    'Email or phone number already registered'

            });

        }


        /*
        |--------------------------------------------------------------------------
        | HASH PASSWORD
        |--------------------------------------------------------------------------
        */

        const hash = await bcrypt.hash(
            password,
            12
        );


        /*
        |--------------------------------------------------------------------------
        | INSERT USER
        |--------------------------------------------------------------------------
        */

        const [r] = await pool.query(

            `
            INSERT INTO users
            (
                full_name,
                email,
                phone_number,
                gender,
                referral,
                password_hash
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
            `,

            [
                full_name,
                email,
                phone_number,
                gender,
                referral || null,
                hash
            ]

        );


        /*
        |--------------------------------------------------------------------------
        | REGISTRATION SUCCESS
        |--------------------------------------------------------------------------
        |
        | No JWT token is created here.
        |
        */

        return res.status(201).json({

            success: true,

            message:
                'Registration successful. Choose a payment method.',

            user_id: r.insertId,

            payment_required: 5000

        });


    } catch (e) {

        /*
        |--------------------------------------------------------------------------
        | ERROR
        |--------------------------------------------------------------------------
        */

        console.error(e);

        return res.status(500).json({

            success: false,

            message: 'Registration failed'

        });

    }

});


/*
|--------------------------------------------------------------------------
| USER LOGIN
|--------------------------------------------------------------------------
| POST /api/auth/login
|
| JWT IS CREATED HERE.
|
| The user logs in using:
| - phone_number
| - password
|--------------------------------------------------------------------------
*/

router.post('/login', async (req, res) => {

    try {

        /*
        |--------------------------------------------------------------------------
        | GET LOGIN DATA
        |--------------------------------------------------------------------------
        */

        const {
            phone_number,
            password
        } = req.body;


        /*
        |--------------------------------------------------------------------------
        | FIND USER
        |--------------------------------------------------------------------------
        */

        const [rows] = await pool.query(

            `
            SELECT *
            FROM users
            WHERE phone_number = ?
            LIMIT 1
            `,

            [
                phone_number
            ]

        );


        /*
        |--------------------------------------------------------------------------
        | USER NOT FOUND
        |--------------------------------------------------------------------------
        */

        if (!rows.length) {

            return res.status(401).json({

                success: false,

                message:
                    'Invalid phone number or password'

            });

        }


        /*
        |--------------------------------------------------------------------------
        | GET USER
        |--------------------------------------------------------------------------
        */

        const u = rows[0];


        /*
        |--------------------------------------------------------------------------
        | CHECK PASSWORD
        |--------------------------------------------------------------------------
        */

        const passwordMatch =
            await bcrypt.compare(
                password,
                u.password_hash
            );


        if (!passwordMatch) {

            return res.status(401).json({

                success: false,

                message:
                    'Invalid phone number or password'

            });

        }


        /*
        |--------------------------------------------------------------------------
        | GET VIRTUAL ACCOUNT
        |--------------------------------------------------------------------------
        */

        const [a] = await pool.query(

            `
            SELECT *
            FROM virtual_account
            WHERE user_id = ?
            LIMIT 1
            `,

            [
                u.id
            ]

        );


        /*
        |--------------------------------------------------------------------------
        | CREATE JWT TOKEN
        |--------------------------------------------------------------------------
        |
        | JWT is created ONLY after successful login.
        |--------------------------------------------------------------------------
        */

        const token = jwt.sign(

            {

                id: u.id,

                phone_number: u.phone_number,

                isAdmin: false

            },

            process.env.JWT_SECRET,

            {

                expiresIn: '7d'

            }

        );


        /*
        |--------------------------------------------------------------------------
        | LOGIN SUCCESS
        |--------------------------------------------------------------------------
        */

        return res.json({

            success: true,

            message: 'Login successful',

            token: token,

            user: publicUser(
                u,
                a[0]
            )

        });


    } catch (e) {

        /*
        |--------------------------------------------------------------------------
        | ERROR
        |--------------------------------------------------------------------------
        */

        console.error(e);

        return res.status(500).json({

            success: false,

            message: 'Login failed'

        });

    }

});


/*
|--------------------------------------------------------------------------
| ADMIN LOGIN
|--------------------------------------------------------------------------
| POST /api/auth/admin/login
|
| Admin logs in with:
| - phone_number
| - password
|
| Admin receives a JWT token with:
| isAdmin: true
|--------------------------------------------------------------------------
*/

router.post('/admin/login', async (req, res) => {

    try {

        /*
        |--------------------------------------------------------------------------
        | GET ADMIN LOGIN DATA
        |--------------------------------------------------------------------------
        */

        const {
            phone_number,
            password
        } = req.body;


        /*
        |--------------------------------------------------------------------------
        | FIND ADMIN
        |--------------------------------------------------------------------------
        */

        const [rows] = await pool.query(

            `
            SELECT *
            FROM admin_users
            WHERE phone_number = ?
            LIMIT 1
            `,

            [
                phone_number
            ]

        );


        /*
        |--------------------------------------------------------------------------
        | ADMIN NOT FOUND
        |--------------------------------------------------------------------------
        */

        if (!rows.length) {

            return res.status(401).json({

                success: false,

                message:
                    'Invalid admin credentials'

            });

        }


        /*
        |--------------------------------------------------------------------------
        | CHECK ADMIN PASSWORD
        |--------------------------------------------------------------------------
        */

        const passwordMatch =
            await bcrypt.compare(

                password,

                rows[0].password_hash

            );


        if (!passwordMatch) {

            return res.status(401).json({

                success: false,

                message:
                    'Invalid admin credentials'

            });

        }


        /*
        |--------------------------------------------------------------------------
        | CREATE ADMIN JWT
        |--------------------------------------------------------------------------
        */

        const token = jwt.sign(

            {

                id: rows[0].id,

                phone_number:
                    rows[0].phone_number,

                isAdmin: true

            },

            process.env.JWT_SECRET,

            {

                expiresIn: '8h'

            }

        );


        /*
        |--------------------------------------------------------------------------
        | ADMIN LOGIN SUCCESS
        |--------------------------------------------------------------------------
        */

        return res.json({

            success: true,

            token: token

        });


    } catch (e) {

        /*
        |--------------------------------------------------------------------------
        | ERROR
        |--------------------------------------------------------------------------
        */

        console.error(e);

        return res.status(500).json({

            success: false,

            message:
                'Admin login failed'

        });

    }

});


/*
|--------------------------------------------------------------------------
| EXPORT ROUTER
|--------------------------------------------------------------------------
*/

module.exports = router;