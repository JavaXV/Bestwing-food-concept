const express = require('express');

const pool = require('../config/db');

const {
    authenticate,
    requireAdmin
} = require('../middleware/auth');

const {
    activateUser
} = require('../services/account');

const router = express.Router();


/*
|--------------------------------------------------------------------------
| GET MANUAL PAYMENTS
|--------------------------------------------------------------------------
|
| Endpoint:
| GET /api/admin/manual-payments
|
| Only authenticated administrators can access this endpoint.
|
|--------------------------------------------------------------------------
*/

router.get(

    '/manual-payments',

    authenticate,

    requireAdmin,

    async (req, res) => {

        try {

            /*
            |--------------------------------------------------------------------------
            | GET PENDING MANUAL PAYMENTS
            |--------------------------------------------------------------------------
            */

            const [rows] = await pool.query(

                `
                SELECT

                    p.id,

                    p.user_id,

                    p.amount,

                    p.reference,

                    p.status,

                    p.created_at,

                    u.full_name,

                    u.email,

                    u.phone_number

                FROM payments p

                JOIN users u
                    ON u.id = p.user_id

                WHERE p.method = 'manual'

                AND p.status = 'awaiting_manual_approval'

                ORDER BY p.created_at DESC
                `

            );


            /*
            |--------------------------------------------------------------------------
            | RETURN MANUAL PAYMENTS
            |--------------------------------------------------------------------------
            */

            return res.json({

                success: true,

                payments: rows

            });


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | ERROR
            |--------------------------------------------------------------------------
            */

            console.error(e);


            return res.status(500).json({

                success: false,

                message:
                    'Unable to load manual payments'

            });

        }

    }

);


/*
|--------------------------------------------------------------------------
| APPROVE MANUAL PAYMENT
|--------------------------------------------------------------------------
|
| Endpoint:
| POST /api/admin/manual-payments/:id/approve
|
| Only authenticated administrators can approve payments.
|
|--------------------------------------------------------------------------
*/

router.post(

    '/manual-payments/:id/approve',

    authenticate,

    requireAdmin,

    async (req, res) => {

        /*
        |--------------------------------------------------------------------------
        | GET DATABASE CONNECTION
        |--------------------------------------------------------------------------
        */

        const conn =
            await pool.getConnection();


        try {

            /*
            |--------------------------------------------------------------------------
            | START DATABASE TRANSACTION
            |--------------------------------------------------------------------------
            */

            await conn.beginTransaction();


            /*
            |--------------------------------------------------------------------------
            | FIND PAYMENT AND LOCK ROW
            |--------------------------------------------------------------------------
            |
            | FOR UPDATE prevents two administrators/processes from
            | approving the same payment at the same time.
            |
            */

            const [p] = await conn.query(

                `
                SELECT *
                FROM payments
                WHERE id = ?
                AND method = 'manual'
                FOR UPDATE
                `,

                [
                    req.params.id
                ]

            );


            /*
            |--------------------------------------------------------------------------
            | PAYMENT NOT FOUND
            |--------------------------------------------------------------------------
            */

            if (!p.length) {

                await conn.rollback();

                return res.status(404).json({

                    success: false,

                    message:
                        'Payment not found'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | CHECK PAYMENT STATUS
            |--------------------------------------------------------------------------
            */

            if (
                p[0].status !==
                'awaiting_manual_approval'
            ) {

                await conn.rollback();

                return res.status(400).json({

                    success: false,

                    message:
                        'Payment is no longer awaiting approval'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | APPROVE PAYMENT
            |--------------------------------------------------------------------------
            */

            await conn.query(

                `
                UPDATE payments
                SET
                    status = 'success',
                    approved_by = ?,
                    approved_at = NOW()
                WHERE id = ?
                `,

                [

                    String(
                        req.auth.id
                    ),

                    p[0].id

                ]

            );


            /*
            |--------------------------------------------------------------------------
            | COMMIT DATABASE TRANSACTION
            |--------------------------------------------------------------------------
            */

            await conn.commit();


            /*
            |--------------------------------------------------------------------------
            | ACTIVATE USER
            |--------------------------------------------------------------------------
            |
            | This should:
            |
            | 1. Change the user's payment status to paid
            | 2. Change account status to active
            | 3. Generate the 10-digit account number
            | 4. Create the virtual account record
            |
            */

            const account =
                await activateUser(
                    p[0].user_id
                );


            /*
            |--------------------------------------------------------------------------
            | RETURN SUCCESS
            |--------------------------------------------------------------------------
            */

            return res.json({

                success: true,

                message:
                    'Manual payment approved',

                account_number:
                    account.accountno

            });


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | ROLLBACK IF SOMETHING FAILS
            |--------------------------------------------------------------------------
            */

            await conn.rollback();


            /*
            |--------------------------------------------------------------------------
            | LOG ERROR
            |--------------------------------------------------------------------------
            */

            console.error(e);


            /*
            |--------------------------------------------------------------------------
            | RETURN ERROR
            |--------------------------------------------------------------------------
            */

            return res.status(500).json({

                success: false,

                message:
                    'Approval failed'

            });


        } finally {

            /*
            |--------------------------------------------------------------------------
            | RELEASE DATABASE CONNECTION
            |--------------------------------------------------------------------------
            */

            conn.release();

        }

    }

);


/*
|--------------------------------------------------------------------------
| REJECT MANUAL PAYMENT
|--------------------------------------------------------------------------
|
| Endpoint:
| POST /api/admin/manual-payments/:id/reject
|
| Only authenticated administrators can reject payments.
|
|--------------------------------------------------------------------------
*/

router.post(

    '/manual-payments/:id/reject',

    authenticate,

    requireAdmin,

    async (req, res) => {

        try {

            /*
            |--------------------------------------------------------------------------
            | REJECT PAYMENT
            |--------------------------------------------------------------------------
            */

            const [r] = await pool.query(

                `
                UPDATE payments

                SET
                    status = 'rejected',
                    approved_by = ?,
                    approved_at = NOW()

                WHERE id = ?

                AND method = 'manual'

                AND status = 'awaiting_manual_approval'
                `,

                [

                    String(
                        req.auth.id
                    ),

                    req.params.id

                ]

            );


            /*
            |--------------------------------------------------------------------------
            | PAYMENT NOT FOUND OR ALREADY PROCESSED
            |--------------------------------------------------------------------------
            */

            if (!r.affectedRows) {

                return res.status(404).json({

                    success: false,

                    message:
                        'Payment not found or already processed'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | RETURN SUCCESS
            |--------------------------------------------------------------------------
            */

            return res.json({

                success: true,

                message:
                    'Manual payment rejected'

            });


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | LOG ERROR
            |--------------------------------------------------------------------------
            */

            console.error(e);


            /*
            |--------------------------------------------------------------------------
            | RETURN ERROR
            |--------------------------------------------------------------------------
            */

            return res.status(500).json({

                success: false,

                message:
                    'Rejection failed'

            });

        }

    }

);


/*
|--------------------------------------------------------------------------
| EXPORT ROUTER
|--------------------------------------------------------------------------
*/

module.exports = router;