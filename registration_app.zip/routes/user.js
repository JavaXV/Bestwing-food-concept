const express = require('express');

const pool = require('../config/db');

const {
    authenticate
} = require('../middleware/auth');

const router = express.Router();


/*
|--------------------------------------------------------------------------
| GET CURRENT USER
|--------------------------------------------------------------------------
| Endpoint:
| GET /api/user/me
|
| This endpoint requires a valid JWT token.
|
| The authenticate middleware reads the token and places
| the decoded user information inside req.auth.
|--------------------------------------------------------------------------
*/

router.get(
    '/me',
    authenticate,
    async (req, res) => {

        try {

            /*
            |--------------------------------------------------------------------------
            | GET USER INFORMATION
            |--------------------------------------------------------------------------
            |
            | We get:
            | - User information
            | - Payment status
            | - Account status
            | - Virtual account number
            | - Virtual account name
            |
            */

            const [rows] = await pool.query(

                `
                SELECT

                    u.id,

                    u.full_name,

                    u.email,

                    u.phone_number,

                    u.gender,

                    u.referral,

                    u.payment_status,

                    u.account_status,

                    u.created_at,

                    v.accountno AS account_number,

                    v.account_name

                FROM users u

                LEFT JOIN virtual_account v
                    ON v.user_id = u.id

                WHERE u.id = ?

                LIMIT 1
                `,

                [
                    req.auth.id
                ]

            );


            /*
            |--------------------------------------------------------------------------
            | USER NOT FOUND
            |--------------------------------------------------------------------------
            */

            if (!rows.length) {

                return res.status(404).json({

                    success: false,

                    message: 'User not found'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | RETURN USER INFORMATION
            |--------------------------------------------------------------------------
            */

            return res.json({

                success: true,

                user: rows[0]

            });


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | SERVER ERROR
            |--------------------------------------------------------------------------
            */

            console.error(e);


            return res.status(500).json({

                success: false,

                message: 'Unable to load dashboard'

            });

        }

    }
);


/*
|--------------------------------------------------------------------------
| EXPORT ROUTER
|--------------------------------------------------------------------------
*/

module.exports = router;