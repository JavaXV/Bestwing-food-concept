const express = require('express');

const axios = require('axios');

const crypto = require('crypto');

const pool = require('../config/db');

const {
    activateUser
} = require('../services/account');

require('dotenv').config();

const router = express.Router();


/*
|--------------------------------------------------------------------------
| REGISTRATION PAYMENT AMOUNT
|--------------------------------------------------------------------------
|
| Registration fee = ₦5,000
|
*/

const AMOUNT_NGN = 5000;


/*
|--------------------------------------------------------------------------
| PAYSTACK INITIALIZE PAYMENT
|--------------------------------------------------------------------------
|
| POST /api/payment/paystack/initialize
|
| No JWT / Authorization is required here.
|
| The user_id is received from the registration process.
|
|--------------------------------------------------------------------------
*/

router.post(
    '/paystack/initialize',
    async (req, res) => {

        try {

            /*
            |--------------------------------------------------------------------------
            | GET USER ID
            |--------------------------------------------------------------------------
            */

            const {
                user_id
            } = req.body;


            /*
            |--------------------------------------------------------------------------
            | CHECK USER ID
            |--------------------------------------------------------------------------
            */

            if (!user_id) {

                return res.status(400).json({

                    success: false,

                    message: 'user_id is required'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | FIND USER
            |--------------------------------------------------------------------------
            */

            const [users] = await pool.query(

                `
                SELECT
                    id,
                    full_name,
                    email,
                    payment_status
                FROM users
                WHERE id = ?
                LIMIT 1
                `,

                [
                    user_id
                ]

            );


            /*
            |--------------------------------------------------------------------------
            | USER NOT FOUND
            |--------------------------------------------------------------------------
            */

            if (!users.length) {

                return res.status(404).json({

                    success: false,

                    message: 'User not found'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | GET USER DATA
            |--------------------------------------------------------------------------
            */

            const u = users[0];


            /*
            |--------------------------------------------------------------------------
            | CHECK IF USER HAS ALREADY PAID
            |--------------------------------------------------------------------------
            */

            if (u.payment_status === 'paid') {

                return res.status(400).json({

                    success: false,

                    message: 'User has already paid'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | CREATE UNIQUE PAYMENT REFERENCE
            |--------------------------------------------------------------------------
            */

            const reference =
                'REG_' +
                Date.now() +
                '_' +
                crypto.randomBytes(5).toString('hex');


            /*
            |--------------------------------------------------------------------------
            | CREATE PAYMENT RECORD
            |--------------------------------------------------------------------------
            */

            await pool.query(

                `
                INSERT INTO payments
                (
                    user_id,
                    method,
                    amount,
                    reference,
                    status
                )
                VALUES
                (
                    ?,
                    'paystack',
                    ?,
                    ?,
                    'pending'
                )
                `,

                [
                    u.id,
                    AMOUNT_NGN,
                    reference
                ]

            );


            /*
            |--------------------------------------------------------------------------
            | INITIALIZE PAYSTACK TRANSACTION
            |--------------------------------------------------------------------------
            */

            const response = await axios.post(

                'https://api.paystack.co/transaction/initialize',

                {

                    email: u.email,

                    /*
                    |--------------------------------------------------------------------------
                    | PAYSTACK EXPECTS AMOUNT IN KOBO
                    |--------------------------------------------------------------------------
                    |
                    | ₦5,000 = 500,000 kobo
                    |
                    */

                    amount: AMOUNT_NGN * 100,

                    reference: reference,

                    callback_url:
                        process.env.PAYSTACK_CALLBACK_URL,

                    metadata: {

                        user_id: u.id,

                        purpose: 'registration_fee'

                    }

                },

                {

                    headers: {

                        Authorization:
                            `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,

                        'Content-Type':
                            'application/json'

                    }

                }

            );


            /*
            |--------------------------------------------------------------------------
            | CHECK PAYSTACK RESPONSE
            |--------------------------------------------------------------------------
            */

            if (!response.data.status) {

                throw new Error(

                    response.data.message ||
                    'Paystack initialization failed'

                );

            }


            /*
            |--------------------------------------------------------------------------
            | RETURN PAYMENT URL
            |--------------------------------------------------------------------------
            */

            return res.json({

                success: true,

                authorization_url:
                    response.data.data.authorization_url,

                access_code:
                    response.data.data.access_code,

                reference: reference

            });


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | ERROR
            |--------------------------------------------------------------------------
            */

            console.error(

                e.response?.data ||
                e

            );


            return res.status(500).json({

                success: false,

                message:
                    'Unable to initialize Paystack payment'

            });

        }

    }
);


/*
|--------------------------------------------------------------------------
| VERIFY PAYSTACK PAYMENT
|--------------------------------------------------------------------------
|
| GET /api/payment/paystack/verify/:reference
|
| No JWT / Authorization is required.
|
|--------------------------------------------------------------------------
*/

router.get(

    '/paystack/verify/:reference',

    async (req, res) => {

        try {

            /*
            |--------------------------------------------------------------------------
            | GET PAYMENT REFERENCE
            |--------------------------------------------------------------------------
            */

            const ref =
                req.params.reference;


            /*
            |--------------------------------------------------------------------------
            | VERIFY TRANSACTION WITH PAYSTACK
            |--------------------------------------------------------------------------
            */

            const response = await axios.get(

                `https://api.paystack.co/transaction/verify/${encodeURIComponent(ref)}`,

                {

                    headers: {

                        Authorization:
                            `Bearer ${process.env.PAYSTACK_SECRET_KEY}`

                    }

                }

            );


            /*
            |--------------------------------------------------------------------------
            | GET PAYSTACK TRANSACTION DATA
            |--------------------------------------------------------------------------
            */

            const data =
                response.data.data;


            /*
            |--------------------------------------------------------------------------
            | CHECK PAYMENT STATUS AND AMOUNT
            |--------------------------------------------------------------------------
            */

            if (

                data.status !== 'success' ||

                Number(data.amount) !==
                    AMOUNT_NGN * 100

            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        'Payment was not successful or amount is incorrect'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | FIND PAYMENT RECORD
            |--------------------------------------------------------------------------
            */

            const [payments] = await pool.query(

                `
                SELECT *
                FROM payments
                WHERE reference = ?
                LIMIT 1
                `,

                [
                    ref
                ]

            );


            /*
            |--------------------------------------------------------------------------
            | PAYMENT RECORD NOT FOUND
            |--------------------------------------------------------------------------
            */

            if (!payments.length) {

                return res.status(404).json({

                    success: false,

                    message:
                        'Payment record not found'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | GET PAYMENT
            |--------------------------------------------------------------------------
            */

            const p =
                payments[0];


            /*
            |--------------------------------------------------------------------------
            | UPDATE PAYMENT STATUS
            |--------------------------------------------------------------------------
            */

            await pool.query(

                `
                UPDATE payments
                SET
                    status = 'success',
                    gateway_response = ?
                WHERE reference = ?
                `,

                [

                    data.gateway_response ||
                    data.status,

                    ref

                ]

            );


            /*
            |--------------------------------------------------------------------------
            | ACTIVATE USER
            |--------------------------------------------------------------------------
            |
            | This should:
            |
            | 1. Mark payment as paid
            | 2. Activate the account
            | 3. Generate the 10-digit account number
            |
            */

            const account =
                await activateUser(
                    p.user_id
                );


            /*
            |--------------------------------------------------------------------------
            | RETURN SUCCESS RESPONSE
            |--------------------------------------------------------------------------
            */

            return res.json({

                success: true,

                message:
                    'Payment verified and account activated',

                account_number:
                    account.accountno,

                account_name:
                    account.account_name,

                user_id:
                    p.user_id

            });


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | ERROR
            |--------------------------------------------------------------------------
            */

            console.error(

                e.response?.data ||
                e

            );


            return res.status(500).json({

                success: false,

                message:
                    'Payment verification failed'

            });

        }

    }

);


/*
|--------------------------------------------------------------------------
| MANUAL PAYMENT
|--------------------------------------------------------------------------
|
| POST /api/payment/manual
|
| No JWT / Authorization is required.
|
| User submits manual payment.
|
| Admin must approve the payment before the account is activated.
|
|--------------------------------------------------------------------------
*/

router.post(

    '/manual',

    async (req, res) => {

        try {

            /*
            |--------------------------------------------------------------------------
            | GET USER ID
            |--------------------------------------------------------------------------
            */

            const {
                user_id
            } = req.body;


            /*
            |--------------------------------------------------------------------------
            | CHECK USER ID
            |--------------------------------------------------------------------------
            */

            if (!user_id) {

                return res.status(400).json({

                    success: false,

                    message:
                        'user_id is required'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | FIND USER
            |--------------------------------------------------------------------------
            */

            const [u] = await pool.query(

                `
                SELECT
                    id,
                    payment_status
                FROM users
                WHERE id = ?
                LIMIT 1
                `,

                [
                    user_id
                ]

            );


            /*
            |--------------------------------------------------------------------------
            | USER NOT FOUND
            |--------------------------------------------------------------------------
            */

            if (!u.length) {

                return res.status(404).json({

                    success: false,

                    message:
                        'User not found'

                });

            }


            /*
            |--------------------------------------------------------------------------
            | CREATE MANUAL PAYMENT REFERENCE
            |--------------------------------------------------------------------------
            */

            const reference =
                'MAN_' +
                Date.now() +
                '_' +
                crypto.randomBytes(5).toString('hex');


            /*
            |--------------------------------------------------------------------------
            | CREATE MANUAL PAYMENT RECORD
            |--------------------------------------------------------------------------
            */

            await pool.query(

                `
                INSERT INTO payments
                (
                    user_id,
                    method,
                    amount,
                    reference,
                    status
                )
                VALUES
                (
                    ?,
                    'manual',
                    ?,
                    ?,
                    'awaiting_manual_approval'
                )
                `,

                [

                    user_id,

                    AMOUNT_NGN,

                    reference

                ]

            );


            /*
            |--------------------------------------------------------------------------
            | CHANGE USER PAYMENT STATUS
            |--------------------------------------------------------------------------
            */

            await pool.query(

                `
                UPDATE users
                SET payment_status = 'pending'
                WHERE id = ?
                `,

                [
                    user_id
                ]

            );


            /*
            |--------------------------------------------------------------------------
            | RETURN SUCCESS
            |--------------------------------------------------------------------------
            */

            return res.status(201).json({

                success: true,

                message:
                    'Manual payment submitted. Wait for admin approval.',

                reference:
                    reference

            });


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | ERROR
            |--------------------------------------------------------------------------
            */

            console.error(e);


            return res.status(500).json({

                success: false,

                message:
                    'Unable to submit manual payment'

            });

        }

    }

);


/*
|--------------------------------------------------------------------------
| PAYSTACK WEBHOOK
|--------------------------------------------------------------------------
|
| POST /api/payment/webhook
|
| Paystack calls this endpoint when payment events occur.
|
| IMPORTANT:
| This endpoint does NOT use JWT.
|
| Paystack authenticates the webhook using:
| x-paystack-signature
|
|--------------------------------------------------------------------------
*/

router.post(

    '/webhook',

    async (req, res) => {

        try {

            /*
            |--------------------------------------------------------------------------
            | GET PAYSTACK SIGNATURE
            |--------------------------------------------------------------------------
            */

            const signature =
                req.headers[
                    'x-paystack-signature'
                ];


            /*
            |--------------------------------------------------------------------------
            | CREATE EXPECTED SIGNATURE
            |--------------------------------------------------------------------------
            */

            const expected =
                crypto
                    .createHmac(
                        'sha512',
                        process.env.PAYSTACK_SECRET_KEY
                    )
                    .update(
                        JSON.stringify(req.body)
                    )
                    .digest('hex');


            /*
            |--------------------------------------------------------------------------
            | VERIFY SIGNATURE
            |--------------------------------------------------------------------------
            */

            if (
                !signature ||
                signature !== expected
            ) {

                return res.sendStatus(401);

            }


            /*
            |--------------------------------------------------------------------------
            | RESPOND TO PAYSTACK IMMEDIATELY
            |--------------------------------------------------------------------------
            */

            res.sendStatus(200);


            /*
            |--------------------------------------------------------------------------
            | CHECK EVENT TYPE
            |--------------------------------------------------------------------------
            */

            if (
                req.body.event !==
                'charge.success'
            ) {

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | GET PAYMENT DATA
            |--------------------------------------------------------------------------
            */

            const data =
                req.body.data;


            /*
            |--------------------------------------------------------------------------
            | CHECK PAYMENT STATUS
            |--------------------------------------------------------------------------
            */

            if (
                data.status !== 'success'
            ) {

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | CHECK PAYMENT AMOUNT
            |--------------------------------------------------------------------------
            */

            if (
                Number(data.amount) !==
                AMOUNT_NGN * 100
            ) {

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | FIND PAYMENT
            |--------------------------------------------------------------------------
            */

            const [payments] =
                await pool.query(

                    `
                    SELECT *
                    FROM payments
                    WHERE reference = ?
                    LIMIT 1
                    `,

                    [
                        data.reference
                    ]

                );


            /*
            |--------------------------------------------------------------------------
            | PAYMENT RECORD NOT FOUND
            |--------------------------------------------------------------------------
            */

            if (!payments.length) {

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | GET PAYMENT
            |--------------------------------------------------------------------------
            */

            const p =
                payments[0];


            /*
            |--------------------------------------------------------------------------
            | PREVENT DUPLICATE ACTIVATION
            |--------------------------------------------------------------------------
            */

            if (
                p.status === 'success'
            ) {

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | UPDATE PAYMENT
            |--------------------------------------------------------------------------
            */

            await pool.query(

                `
                UPDATE payments
                SET
                    status = 'success',
                    gateway_response = ?
                WHERE reference = ?
                `,

                [

                    data.gateway_response ||
                    data.status,

                    data.reference

                ]

            );


            /*
            |--------------------------------------------------------------------------
            | ACTIVATE USER
            |--------------------------------------------------------------------------
            */

            await activateUser(
                p.user_id
            );


        } catch (e) {

            /*
            |--------------------------------------------------------------------------
            | WEBHOOK ERROR
            |--------------------------------------------------------------------------
            */

            console.error(
                'Webhook error',
                e
            );

        }

    }

);


/*
|--------------------------------------------------------------------------
| PAYSTACK CALLBACK
|--------------------------------------------------------------------------
|
| GET /api/payment/callback
|
| After Paystack completes the payment, the user is redirected here.
|
|--------------------------------------------------------------------------
*/

router.get(

    '/callback',

    async (req, res) => {

        /*
        |--------------------------------------------------------------------------
        | GET PAYMENT REFERENCE
        |--------------------------------------------------------------------------
        */

        const ref =
            req.query.reference;


        /*
        |--------------------------------------------------------------------------
        | REFERENCE NOT FOUND
        |--------------------------------------------------------------------------
        */

        if (!ref) {

            return res.redirect(
                '/payment.html?status=failed'
            );

        }


        /*
        |--------------------------------------------------------------------------
        | REDIRECT TO PAYMENT PAGE
        |--------------------------------------------------------------------------
        */

        return res.redirect(

            `/payment.html?reference=${encodeURIComponent(ref)}&verify=1`

        );

    }

);


/*
|--------------------------------------------------------------------------
| EXPORT PAYMENT ROUTER
|--------------------------------------------------------------------------
*/

module.exports = router;