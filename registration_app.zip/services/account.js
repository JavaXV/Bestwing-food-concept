const pool = require('../config/db');


/*
|--------------------------------------------------------------------------
| GENERATE UNIQUE 10-DIGIT ACCOUNT NUMBER
|--------------------------------------------------------------------------
|
| This function generates a random 10-digit account number.
|
| It checks the virtual_account table to make sure the number
| has not already been assigned to another user.
|
|--------------------------------------------------------------------------
*/

async function generateAccountNumber(conn) {


    /*
    |--------------------------------------------------------------------------
    | TRY UP TO 30 TIMES
    |--------------------------------------------------------------------------
    */

    for (
        let i = 0;
        i < 30;
        i++
    ) {


        /*
        |--------------------------------------------------------------------------
        | GENERATE RANDOM 10-DIGIT NUMBER
        |--------------------------------------------------------------------------
        |
        | Example:
        |
        | 1023456789
        | 5839201746
        | 9172635401
        |
        */

        const number = String(

            Math.floor(

                1000000000 +
                Math.random() *
                9000000000

            )

        );


        /*
        |--------------------------------------------------------------------------
        | CHECK IF ACCOUNT NUMBER ALREADY EXISTS
        |--------------------------------------------------------------------------
        */

        const [rows] = await conn.query(

            `
            SELECT id
            FROM virtual_account
            WHERE accountno = ?
            LIMIT 1
            `,

            [
                number
            ]

        );


        /*
        |--------------------------------------------------------------------------
        | NUMBER IS AVAILABLE
        |--------------------------------------------------------------------------
        */

        if (!rows.length) {

            return number;

        }

    }


    /*
    |--------------------------------------------------------------------------
    | FAILED TO GENERATE UNIQUE NUMBER
    |--------------------------------------------------------------------------
    */

    throw new Error(

        'Unable to generate unique account number'

    );

}


/*
|--------------------------------------------------------------------------
| ACTIVATE USER
|--------------------------------------------------------------------------
|
| This function is called after successful payment.
|
| It performs the following:
|
| 1. Finds the user
| 2. Locks the user row
| 3. Changes payment_status to "paid"
| 4. Changes account_status to "active"
| 5. Checks whether the user already has an account
| 6. Creates a 10-digit account number if necessary
| 7. Creates the virtual account
| 8. Commits the transaction
|
|--------------------------------------------------------------------------
*/

async function activateUser(userId) {


    /*
    |--------------------------------------------------------------------------
    | GET DATABASE CONNECTION
    |--------------------------------------------------------------------------
    */

    const conn =
        await pool.getConnection();


    try {


        /*
        |--------------------------------------------------------------------------
        | START DATABASE TRANSACTION
        |--------------------------------------------------------------------------
        */

        await conn.beginTransaction();


        /*
        |--------------------------------------------------------------------------
        | FIND USER
        |--------------------------------------------------------------------------
        |
        | FOR UPDATE locks the user row until the transaction completes.
        |
        */

        const [users] = await conn.query(

            `
            SELECT *
            FROM users
            WHERE id = ?
            FOR UPDATE
            `,

            [
                userId
            ]

        );


        /*
        |--------------------------------------------------------------------------
        | CHECK IF USER EXISTS
        |--------------------------------------------------------------------------
        */

        if (!users.length) {

            throw new Error(

                'User not found'

            );

        }


        /*
        |--------------------------------------------------------------------------
        | GET USER
        |--------------------------------------------------------------------------
        */

        const user =
            users[0];


        /*
        |--------------------------------------------------------------------------
        | ACTIVATE USER
        |--------------------------------------------------------------------------
        |
        | Only update the user if the account is not already active.
        |
        */

        if (
            !user.account_status ||
            user.account_status !== 'active'
        ) {


            await conn.query(

                `
                UPDATE users

                SET
                    payment_status = 'paid',
                    account_status = 'active'

                WHERE id = ?
                `,

                [
                    userId
                ]

            );

        }


        /*
        |--------------------------------------------------------------------------
        | CHECK FOR EXISTING VIRTUAL ACCOUNT
        |--------------------------------------------------------------------------
        */

        const [existing] =
            await conn.query(

                `
                SELECT *
                FROM virtual_account
                WHERE user_id = ?
                LIMIT 1
                `,

                [
                    userId
                ]

            );


        /*
        |--------------------------------------------------------------------------
        | GET EXISTING ACCOUNT
        |--------------------------------------------------------------------------
        */

        let account =
            existing[0];


        /*
        |--------------------------------------------------------------------------
        | CREATE VIRTUAL ACCOUNT IF IT DOES NOT EXIST
        |--------------------------------------------------------------------------
        */

        if (!account) {


            /*
            |--------------------------------------------------------------------------
            | GENERATE UNIQUE 10-DIGIT ACCOUNT NUMBER
            |--------------------------------------------------------------------------
            */

            const accountno =
                await generateAccountNumber(
                    conn
                );


            /*
            |--------------------------------------------------------------------------
            | INSERT VIRTUAL ACCOUNT
            |--------------------------------------------------------------------------
            */

            await conn.query(

                `
                INSERT INTO virtual_account
                (
                    user_id,
                    accountno,
                    account_name
                )
                VALUES
                (
                    ?,
                    ?,
                    ?
                )
                `,

                [

                    userId,

                    accountno,

                    user.full_name

                ]

            );


            /*
            |--------------------------------------------------------------------------
            | GET NEWLY CREATED ACCOUNT
            |--------------------------------------------------------------------------
            */

            const [created] =
                await conn.query(

                    `
                    SELECT *
                    FROM virtual_account
                    WHERE user_id = ?
                    `,

                    [
                        userId
                    ]

                );


            /*
            |--------------------------------------------------------------------------
            | STORE CREATED ACCOUNT
            |--------------------------------------------------------------------------
            */

            account =
                created[0];

        }


        /*
        |--------------------------------------------------------------------------
        | COMMIT DATABASE TRANSACTION
        |--------------------------------------------------------------------------
        */

        await conn.commit();


        /*
        |--------------------------------------------------------------------------
        | RETURN ACCOUNT INFORMATION
        |--------------------------------------------------------------------------
        */

        return account;


    } catch (e) {


        /*
        |--------------------------------------------------------------------------
        | ROLLBACK TRANSACTION
        |--------------------------------------------------------------------------
        |
        | If anything fails, all database changes made in this
        | transaction are cancelled.
        |
        */

        await conn.rollback();


        /*
        |--------------------------------------------------------------------------
        | SEND ERROR BACK TO CALLER
        |--------------------------------------------------------------------------
        */

        throw e;


    } finally {


        /*
        |--------------------------------------------------------------------------
        | RELEASE DATABASE CONNECTION
        |--------------------------------------------------------------------------
        */

        conn.release();

    }

}


/*
|--------------------------------------------------------------------------
| EXPORT ACTIVATE USER
|--------------------------------------------------------------------------
*/

module.exports = {

    activateUser

};